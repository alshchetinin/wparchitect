<?php get_header(); ?>
<h1>Привет</h1>

<?php get_footer(); ?>